import ply.lex as lex

resultado_lexema = []

# Definimos las palabras reservadas
reservadas = (
    "for",
    "system",
    "out",
    "printl",
)
# Se definen los tokens que seran indentificados por el analizador
tokens = reservadas + (
    "IDENTIFICADOR",
    "ENTERO",
    "SUMA",
    "RESTA",
    "MULTIPLICACION",
    "DIVISION",
    "IGUAL",
    "MENOR",
    "MAYOR",
    "MENORIGUAL",
    "MAYORIGUAL",
    "DISTINTO",
    "PARIZQ",
    "PARDER",
    "LLAVEIZQ",
    "LLAVEDER",
    "COMA",
    "PUNTOCOMA",
    "DOSPUNTOS",
    "COMENTARIO",
    "PUNTO", 
)
# Aqui se muestran las reglas que debe seguir el analizador lexico
t_SUMA = r"\+"
t_RESTA = r"-"
t_MULTIPLICACION = r"\*"
t_DIVISION = r"/"
t_IGUAL = r"="
t_MENOR = r"<"
t_MAYOR = r">"
t_MENORIGUAL = r"<="
t_MAYORIGUAL = r">="
t_DISTINTO = r"!="  
t_PARIZQ = r"\("
t_PARDER = r"\)"
t_LLAVEIZQ = r"\{"
t_LLAVEDER = r"\}"
t_COMA = r","
t_PUNTOCOMA = r";"
t_DOSPUNTOS = r":"
t_COMENTARIO = r"//.*"
t_PUNTO = r"."

# Esto se usa para ignorar los espacios en blanco
t_ignore = " \t"

def t_IDENTIFICADOR(t):
    r"[a-zA-Z_][a-zA-Z0-9_]*"
    t.type = t.value.upper() if t.value.upper() in reservadas else "IDENTIFICADOR"
    return t

def t_ENTERO(t):
    r"\d+"
    t.value = int(t.value)
    return t

def t_newline(t):
    r"\n+"
    t.lexer.lineno += len(t.value)

def t_error(t):
    print(f"Caracter no válido '{t.value[0]}'")
    t.lexer.skip(1)

def t_UNKNOWN(t):
    r"\#"
    print(f"Token desconocido '{t.value[0]}'")
    t.lexer.skip(1)

def prueba(data):
    lexer.input(data)
    while True:
        tok = lexer.token()
        if not tok:
            break
        print(tok)
# Construimos el lexer
lexer = lex.lex()

if __name__ == "__main__":
    while True:
        data = input("Ingrese un dato: ")
        prueba(data)
