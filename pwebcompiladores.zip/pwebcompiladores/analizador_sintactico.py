import ply.yacc as yacc
# Importamos los tokens y el analizador
from analizador_lexico import tokens
from analizador_lexico import lexer
# Creamos las reglas de produccion
def p_term(p):
    '''term : ENTERO 
            | IDENTIFICADOR '''
    p[0] = p[1]

def p_sum(p):
    '''term : term SUMA term '''

def p_parentesis(p):
    '''term : PARIZQ term PARDER ''' # <{:v   //:=v
    p[0]  = p[2]


def p_empty(p):
    'empty : '
    pass

def p_error(p):
    if p:
        print(f"Error sintáctico: Token inesperado '{p.value}' ")
    else:
        print("No hay nah")

parser = yacc.yacc()


